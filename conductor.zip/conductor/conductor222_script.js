function showPopup(message) {
    alert(message);
}
